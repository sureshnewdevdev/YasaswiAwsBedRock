BEDROCK WEB CHAT - SUPER BEGINNER SETUP (WINDOWS CMD)
====================================================

GOAL
----
Run an HTML + JavaScript chat application with a FastAPI Python backend.
The backend calls the Amazon Bedrock Mantle OpenAI-compatible Responses API.
This project calls a Bedrock FOUNDATION MODEL; it does not invoke a Bedrock Agent ID.

IMPORTANT SECURITY
------------------
- Never paste a real API key into Python, HTML, JavaScript, or this README.
- If you shared a key in a chat or screenshot, revoke it and generate a new one.
- The browser only talks to your local FastAPI server. Your key remains on the backend.
- Do not expose this demonstration server publicly or deploy it as-is.

FILES INCLUDED
--------------
server.py        Python FastAPI backend (API request /api/chat)
index.html       HTML chat window
style.css        Page design
script.js        JavaScript to send questions and display answers
requirements.txt Required Python packages
README.txt       You are reading this file

STEP 1. COPY THE FILES
----------------------
Extract the ZIP and copy ALL SIX files directly into:

    C:\AwsBebrock\CallBR

Keep your existing app.py file. Do not replace it.
The folder should look like this:

    C:\AwsBebrock\CallBR\
      app.py                 (your original working sample)
      server.py
      index.html
      style.css
      script.js
      requirements.txt
      README.txt

STEP 2. OPEN WINDOWS COMMAND PROMPT
-----------------------------------
Press Windows + R, type cmd, and press Enter.
Run:

    cd /d C:\AwsBebrock\CallBR

STEP 3. INSTALL PYTHON PACKAGES
-------------------------------
Run:

    python -m pip install -r requirements.txt

Check that this finishes without errors. Python 3.11+ is recommended.

STEP 4. SET ENVIRONMENT VARIABLES IN THE SAME CMD WINDOW
---------------------------------------------------------
Get a NEW Bedrock API key if an old one was exposed.
Use the correct Windows CMD form with quotes AROUND the whole assignment:

    set "OPENAI_BASE_URL=https://bedrock-mantle.us-east-1.api.aws/v1"
    set "OPENAI_API_KEY=PASTE_YOUR_NEW_BEDROCK_API_KEY_HERE"
    set "BEDROCK_MODEL=openai.gpt-oss-120b"

VERY IMPORTANT:
- Use your own NEW key, not the placeholder value above.
- Do NOT use set OPENAI_BASE_URL="https://..." because CMD stores the
  inner quotes and you can get UnsupportedProtocol errors.
- The key and chosen model must work in your AWS account and Region.
- The 'set' values are available only in the current CMD session.

STEP 5. START FASTAPI
---------------------
In the SAME CMD window, run:

    python -m uvicorn server:app --host 127.0.0.1 --port 8000 --reload

What this means:
- server = server.py
- app = FastAPI object in the file
- 127.0.0.1 = your local computer only
- 8000 = the port your browser accesses
- --reload = restart the server automatically after code changes (development only)

Expected terminal message (similar):
    Uvicorn running on http://127.0.0.1:8000

Leave this CMD window OPEN while using the site.

STEP 6. OPEN THE WEB APP
------------------------
Open Chrome / Edge and visit:

    http://127.0.0.1:8000

Do not double-click index.html and open it as file://; open through FastAPI.

STEP 7. ASK QUESTIONS
---------------------
Try:
    What is Amazon Bedrock?
    Explain AWS EC2 in simple words.
    Give three examples of AI agents.

Click Send question or press Enter. Shift+Enter creates a new line.
Click Clear chat to start a fresh conversation.

STEP 8. UNDERSTAND THE DATA FLOW
--------------------------------
1. You enter a question in index.html.
2. script.js sends a POST request to /api/chat.
3. server.py receives the question and reads OPENAI_API_KEY on the server.
4. The Python OpenAI SDK sends it to your Bedrock Mantle endpoint.
5. Bedrock returns an answer to server.py.
6. FastAPI returns JSON {"answer": "...", "model": "..."}.
7. JavaScript safely displays the answer on the HTML page.

STEP 9. STOP THE SERVER
-----------------------
Click the CMD terminal and press Ctrl+C.

TROUBLESHOOTING
---------------
1) 'No module named fastapi' / 'No module named openai':
       python -m pip install -r requirements.txt
2) 'API key missing':
       Set OPENAI_API_KEY in the SAME CMD window as Uvicorn and restart it.
3) 'UnsupportedProtocol':
       Check OPENAI_BASE_URL; use set "NAME=value" syntax, not set NAME="value".
4) 401 / 403:
       Check Bedrock API key, its expiry, AWS permissions and model access.
5) 404:
       Check region, endpoint URL, model ID, and API support.
6) 'Address already in use':
       Stop the old server with Ctrl+C or use --port 8001, then open :8001.
7) 'Failed to fetch' in browser:
       Open http://127.0.0.1:8000 not file://; check Uvicorn terminal.
8) Slow responses or timeouts:
       Retry. Network connectivity and AWS service latency affect response time.
9) Python executable confusion:
       where python
       python --version
       python -m pip --version

OPTIONAL ENDPOINTS
------------------
http://127.0.0.1:8000/api/health   Backend/API-key configuration status
http://127.0.0.1:8000/docs         Interactive FastAPI API documentation

COST REMINDER
-------------
Amazon Bedrock model invocations may incur AWS charges. Close the server when done.

NOTE ABOUT AGENTS
-----------------
You previously asked about Agents created in the AWS Console. This particular
web app uses your CURRENT working OpenAI-compatible Bedrock foundation model
configuration. It does NOT use Agent ID or Agent Alias ID. A real Bedrock Agents
Classic connection would instead require a separate boto3 invoke_agent backend.
