"""FastAPI backend for a browser-based AWS Bedrock Mantle chatbot.

Uses the same OpenAI-compatible Responses API configuration as app.py.
Environment variables:
  OPENAI_API_KEY   = Amazon Bedrock API key (keep secret)
  OPENAI_BASE_URL  = https://bedrock-mantle.us-east-1.api.aws/v1
  BEDROCK_MODEL   = openai.gpt-oss-120b (optional)
"""

import os
import logging
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from openai import OpenAI, APIConnectionError, APIStatusError, APITimeoutError
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent
app = FastAPI(title="Bedrock Web Chat", version="1.0.0")
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("bedrock-chat")


class Message(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(min_length=1, max_length=10000)


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=10000)
    history: list[Message] = Field(default_factory=list, max_length=20)


class ChatResponse(BaseModel):
    answer: str
    model: str


@app.get("/", include_in_schema=False)
def homepage():
    return FileResponse(ROOT / "index.html")


@app.get("/style.css", include_in_schema=False)
def stylesheet():
    return FileResponse(ROOT / "style.css", media_type="text/css")


@app.get("/script.js", include_in_schema=False)
def javascript():
    return FileResponse(ROOT / "script.js", media_type="text/javascript")


@app.get("/api/health")
def health():
    # Do not report the actual API key to the browser.
    return {"status": "ok", "configured": bool(os.getenv("OPENAI_API_KEY")),
            "model": os.getenv("BEDROCK_MODEL", "openai.gpt-oss-120b")}


@app.post("/api/chat", response_model=ChatResponse)
def chat(request: ChatRequest):
    api_key = (os.getenv("OPENAI_API_KEY") or "").strip().strip('"')
    base_url = (os.getenv("OPENAI_BASE_URL") or "https://bedrock-mantle.us-east-1.api.aws/v1").strip().strip('"')
    model = (os.getenv("BEDROCK_MODEL") or "openai.gpt-oss-120b").strip().strip('"')
    if not api_key:
        raise HTTPException(status_code=503, detail="OPENAI_API_KEY is missing. See README.txt.")
    if not base_url.startswith(("http://", "https://")):
        raise HTTPException(status_code=503, detail="OPENAI_BASE_URL must begin with https://.")

    # The latest user message follows up to 20 earlier messages, in order.
    messages = [m.model_dump() for m in request.history]
    messages.append({"role": "user", "content": request.message})

    try:
        client = OpenAI(api_key=api_key, base_url=base_url, timeout=60.0, max_retries=1)
        result = client.responses.create(model=model, input=messages)
        answer = (result.output_text or "").strip()
        if not answer:
            raise HTTPException(status_code=502, detail="Bedrock returned no text. Try a different question.")
        return ChatResponse(answer=answer, model=model)
    except APITimeoutError:
        raise HTTPException(status_code=504, detail="Bedrock request timed out. Please retry.")
    except APIConnectionError:
        raise HTTPException(status_code=502, detail="Cannot connect to Bedrock. Check the endpoint and network.")
    except APIStatusError as exc:
        logger.warning("Bedrock returned HTTP %s", exc.status_code)
        if exc.status_code in (401, 403):
            detail = "Bedrock authorization failed. Check the API key and AWS permissions."
        elif exc.status_code == 429:
            detail = "Bedrock rate limit reached. Try again shortly."
        elif exc.status_code == 404:
            detail = "Model or API route not found. Check model and Bedrock endpoint."
        else:
            detail = f"Bedrock returned HTTP {exc.status_code}. Check server logs."
        raise HTTPException(status_code=502, detail=detail)
    except HTTPException:
        raise
    except Exception:
        logger.exception("Unexpected chat error")
        raise HTTPException(status_code=500, detail="Unexpected server error. Check the terminal.")
