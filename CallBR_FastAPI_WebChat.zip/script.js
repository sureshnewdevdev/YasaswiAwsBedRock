const conversation = document.getElementById("conversation");
const form = document.getElementById("chat-form");
const question = document.getElementById("question");
const sendButton = document.getElementById("send-button");
const clearButton = document.getElementById("clear-button");
const feedback = document.getElementById("feedback");
const status = document.getElementById("status");
let history = []; // Sent only from this browser session; no database is used.
let busy = false;

function addMessage(role, message) {
  const welcome = conversation.querySelector(".welcome");
  if (welcome) welcome.remove();
  const article = document.createElement("article");
  article.className = `message ${role}`;
  const who = document.createElement("span");
  who.className = "who";
  who.textContent = role === "user" ? "You" : "Bedrock AI";
  const body = document.createElement("div");
  body.textContent = message; // textContent avoids treating model output as HTML.
  article.append(who, body);
  conversation.appendChild(article);
  conversation.scrollTop = conversation.scrollHeight;
}

async function checkHealth() {
  try {
    const response = await fetch("/api/health");
    if (!response.ok) throw new Error("Server not ready");
    const result = await response.json();
    status.textContent = result.configured ? "Backend ready" : "API key missing";
    status.className = result.configured ? "status ready" : "status bad";
  } catch (_) {
    status.textContent = "Backend offline";
    status.className = "status bad";
  }
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (busy) return;
  const message = question.value.trim();
  if (!message) return;
  feedback.textContent = "";
  const previousHistory = history.slice(-20);
  addMessage("user", message);
  question.value = "";
  busy = true;
  sendButton.disabled = true;
  sendButton.textContent = "Thinking…";
  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, history: previousHistory })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(typeof data.detail === "string" ? data.detail : "Request failed");
    addMessage("assistant", data.answer);
    history.push({ role: "user", content: message }, { role: "assistant", content: data.answer });
    history = history.slice(-20);
  } catch (error) {
    feedback.textContent = error.message;
    addMessage("assistant", "Sorry, I couldn't complete that request. See the error below and check your server terminal.");
  } finally {
    busy = false;
    sendButton.disabled = false;
    sendButton.textContent = "Send question ➤";
    question.focus();
  }
});

question.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey && !event.isComposing) {
    event.preventDefault();
    form.requestSubmit();
  }
});

clearButton.addEventListener("click", () => {
  if (busy) return;
  history = [];
  conversation.replaceChildren();
  const welcome = document.createElement("article");
  welcome.className = "welcome";
  const title = document.createElement("h2");
  title.textContent = "New conversation";
  const detail = document.createElement("p");
  detail.textContent = "Ask your next question below.";
  welcome.append(title, detail);
  conversation.append(welcome);
  feedback.textContent = "";
  question.focus();
});

checkHealth();
