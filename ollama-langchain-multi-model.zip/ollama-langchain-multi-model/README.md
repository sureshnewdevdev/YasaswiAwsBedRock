# LangChain + your local Ollama models

A beginner lab with five small console examples. Python 3.10+ (3.11 recommended), Ollama and the models listed below are required. There is no cloud API key, vector database, web server, LangGraph or LangSmith requirement. Installing Python dependencies needs internet access; inference uses your configured Ollama server.

## Your installed models

| Exact tag | Role | Size reported by you |
|---|---|---|
| `llama3.2:1b` | Lightweight starting chat model | 1.3 GB |
| `phi3:latest` | Second chat model for comparison/review | 2.2 GB |
| `llama3.2:latest` | Alternative chat model | 2.0 GB |
| `qwen3:8b` | Optional larger chat model | 5.2 GB |
| `nomic-embed-text:latest` | Embedding vectors for retrieval | 274 MB |

Model roles here are teaching choices, not measured quality rankings. `nomic-embed-text` does not generate chat answers. Installed file size is not peak RAM usage. Tags such as `latest` can point to different versions after a future pull; these scripts use the exact local tags and never download models.

## 1. Extract and open the project

Extract the ZIP. In VS Code choose **File > Open Folder** and select `ollama-langchain-multi-model`, the folder containing this README. Open a terminal there.

Check Python and Ollama:

```powershell
py --version
ollama --version
ollama list
```

On Ubuntu/macOS use `python3 --version` in place of `py --version`. Keep Ollama running. On Windows, open the Ollama application. If no server is running, use a separate terminal:

```text
ollama serve
```

If this says the port/address is already in use, an Ollama server may already be running. Continue with the connection check instead of starting a second server. Your models are already installed, so no pull is needed for this lab.

## 2. Install dependencies — Windows PowerShell

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe check_setup.py
```

These commands use the virtual environment directly; activation and an execution-policy change are unnecessary. A missing-model message means the tag does not match `ollama list`. After installation, optionally record your actual dependency versions:

```powershell
.\.venv\Scripts\python.exe -m pip freeze > requirements-local-lock.txt
```

`requirements.txt` uses compatible major-version ranges, not an exact tested lockfile.

## 2b. Install dependencies — Ubuntu/macOS

```bash
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python check_setup.py
```

If Ubuntu reports that venv is unavailable, install your distribution's `python3-venv` package first. In all commands below, Ubuntu/macOS users replace `.\.venv\Scripts\python.exe` with `.venv/bin/python`.

## 3. Lesson 1 — choose one model

```powershell
.\.venv\Scripts\python.exe 01_single_model.py
.\.venv\Scripts\python.exe 01_single_model.py --model phi3:latest --question "Explain REST APIs in three sentences."
.\.venv\Scripts\python.exe 01_single_model.py --model llama3.2:latest
.\.venv\Scripts\python.exe 01_single_model.py --model qwen3:8b --max-tokens 512
```

Expected structure: `Model: ...` followed by generated text. Wording varies. All chat models use the same `ChatOllama` interface; only the model tag changes.

## 4. Lesson 2 — compare multiple models

```powershell
.\.venv\Scripts\python.exe 02_compare_models.py
.\.venv\Scripts\python.exe 02_compare_models.py --models llama3.2:1b phi3:latest llama3.2:latest qwen3:8b --question "What is dependency injection?"
```

Every model receives the same question. Calls run one at a time. Output contains a model heading, answer and elapsed seconds for each. Timings include loading and are demonstrations, not controlled benchmarks. A failed call is reported and the loop tries the remaining models, then exits with an error status if any failed.

## 5. Lesson 3 — a writer and reviewer

```powershell
.\.venv\Scripts\python.exe 03_two_model_pipeline.py --topic "Explain async and await in C#"
.\.venv\Scripts\python.exe 03_two_model_pipeline.py --writer llama3.2:latest --reviewer phi3:latest --topic "Explain database indexing"
```

`llama3.2:1b` drafts by default. Its output becomes an input to `phi3:latest`, which rewrites it. Each stage is a LangChain expression: `prompt | model | StrOutputParser()`. This is a two-stage workflow; the reviewer can still make mistakes. Confirm technical claims yourself.

## 6. Lesson 4 — route by task

```powershell
.\.venv\Scripts\python.exe 04_route_models.py --task quick --question "What is HTTP?"
.\.venv\Scripts\python.exe 04_route_models.py --task detailed --question "Explain HTTP methods"
.\.venv\Scripts\python.exe 04_route_models.py --task detailed --model qwen3:8b --question "Explain HTTP methods"
```

The application maps `quick` to `llama3.2:1b`, and `detailed` to `phi3:latest`. It invokes only the selected model. This is an explicit Python routing rule, not an autonomous agent or an automatic quality classifier. `--model` overrides the selected route.

## 7. Lesson 5 — embeddings + chat (mini RAG)

```powershell
.\.venv\Scripts\python.exe 05_embeddings_rag.py
.\.venv\Scripts\python.exe 05_embeddings_rag.py --model phi3:latest --question "What should I do if my laptop breaks?" --top-k 1
```

The three fictional company policies live in `data/policies.json`:

1. `OllamaEmbeddings` sends document text to `nomic-embed-text:latest` and receives numeric vectors.
2. It embeds the question with the same embedding model.
3. Python cosine similarity ranks the documents; the best `--top-k` excerpts form the context.
4. `ChatOllama` sends that context and question to your chosen chat model.
5. The script prints retrieved evidence, generated answer and retrieved source IDs.

For the default question, the intended evidence is `production-access-v1`: approval comes from the manager and platform operations; access lasts 24 hours. This is sample policy data, not real company guidance. Retrieval is semantic and can choose the wrong excerpt; inspect the printed evidence. Retrieved source IDs describe the evidence supplied, not verified model citations. The tiny lab rebuilds all vectors on each run, stores them in memory, and uses no vector database. `search_document:` and `search_query:` distinguish the document/query embedding tasks. Do not change embedding models for just one side: both vectors must share the same embedding space.

## 8. What the common code means

- `base_url`: Ollama HTTP endpoint, normally `http://127.0.0.1:11434`.
- `temperature=0.2`: requests less variable responses; does not promise identical output.
- `num_ctx=2048`: small context setting for this short lab.
- `num_predict`: maximum generated token budget; set with `--max-tokens`.
- `keep_alive=0`: asks Ollama to unload a chat model after a response, reducing resident model memory but adding reload time. The embedding client's default residency can differ.
- `reasoning=False`: used for `qwen3:8b` to request a direct answer instead of a thinking phase; requires a compatible Ollama/model version.
- `client_kwargs`: timeout and disabled inherited proxy settings for the configured connection.
- `require_models`: checks `/api/tags` before generation and reports missing exact tags.
- `invoke`: performs a blocking model call and returns an AI message. `text_content` extracts the answer text.
- `prompt | model | parser`: LangChain's runnable composition, often called LCEL. The parser returns a string.

`--timeout` defaults to 240 seconds; it is a client operation timeout, not a strict total workflow deadline. `--max-tokens` defaults to 384. Most examples support these shared options:

```powershell
.\.venv\Scripts\python.exe 01_single_model.py --model phi3:latest --timeout 600 --max-tokens 512 --base-url http://127.0.0.1:11434
```

Set `OLLAMA_BASE_URL` to change the default server URL. Prefer loopback for this lab. Using a remote URL sends the prompts and policy excerpts to that server.

## 9. Troubleshooting

| Symptom | Action |
|---|---|
| Cannot reach Ollama | Open Ollama or start `ollama serve` if no instance is running; check `--base-url`. |
| Missing exact model tag | Run `ollama list`; choose one of your listed tags. |
| `No module named langchain_ollama` | Run the dependency installation with the same virtual-environment Python used for the scripts. |
| Slow first response | Model loading takes time. Start with `llama3.2:1b`; increase `--timeout` if needed. |
| RAM pressure or model load error | Close other model sessions, inspect `ollama ps`, use the 1b model, and avoid simultaneous heavy calls. You can stop a loaded model with `ollama stop MODEL_TAG`. |
| Empty or truncated answer | Increase `--max-tokens`; for Qwen check thinking support and update Ollama if needed. |
| Qwen thinking-setting error | Check the current Ollama thinking documentation and installed model version; use `phi3:latest` to continue the lab. |
| Unexpected policy answer | Inspect retrieved evidence, rephrase the query, or try `--top-k 2`; ranking is not guaranteed. |
| Port already in use | Check whether Ollama is already running; do not start duplicate servers. |

The examples do not enable LangSmith tracing. If your shell has tracing configured from another project, clear `LANGSMITH_TRACING`, `LANGCHAIN_TRACING_V2`, `LANGSMITH_API_KEY` and `LANGCHAIN_API_KEY` from this process before running with sensitive data. Package installation is online; subsequent local inference does not require a paid model API.

## 10. Practice tasks

1. Ask the same C# question to all four chat models. Compare correctness manually.
2. Swap the writer/reviewer model tags. Observe the draft and rewrite.
3. Change the detailed task route in `04_route_models.py` to `llama3.2:latest`.
4. Add a fourth fictional policy with a unique ID; ask a question that it answers.
5. Ask a question absent from the policies. Inspect whether the model says evidence is missing.

## 11. Files and checks

```text
ollama-langchain-multi-model/
  README.md
  requirements.txt
  tutorial.html
  common.py
  check_setup.py
  01_single_model.py
  02_compare_models.py
  03_two_model_pipeline.py
  04_route_models.py
  05_embeddings_rag.py
  data/policies.json
  tests/test_common.py
```

Open `tutorial.html` directly in your browser for the illustrated lessons. To check helper behavior without contacting Ollama:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Delivery verification: Python syntax, helper unit tests and CLI help were checked in the authoring environment. A live Ollama server and your local models were unavailable there, so generated answers and end-to-end inference have not been verified. Run `check_setup.py`, then Lesson 1 locally first.

## Official references

- [LangChain ChatOllama](https://docs.langchain.com/oss/python/integrations/chat/ollama)
- [LangChain OllamaEmbeddings](https://docs.langchain.com/oss/python/integrations/embeddings/ollama)
- [ChatOllama API reference](https://reference.langchain.com/python/langchain-ollama/chat_models/ChatOllama)
- [Ollama model list API](https://docs.ollama.com/api/tags)
- [Ollama memory and configuration FAQ](https://docs.ollama.com/faq)
- [Ollama thinking support](https://docs.ollama.com/capabilities/thinking)
- [nomic-embed-text model](https://ollama.com/library/nomic-embed-text)

Prepared for your exact supplied model list on 11 November 2026. Keep your generated local dependency lock for reproducible classroom setup.
