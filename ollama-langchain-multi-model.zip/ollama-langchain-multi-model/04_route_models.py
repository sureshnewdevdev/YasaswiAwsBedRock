"""Lesson 4: an explicit task label selects one model."""
import argparse
from common import CHAT_MODELS, add_settings, make_chat, require_models, run_cli, text_content

DEFAULT_ROUTE = {"quick": "llama3.2:1b", "detailed": "phi3:latest"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    add_settings(parser)
    parser.add_argument("--task", choices=DEFAULT_ROUTE, default="quick")
    parser.add_argument("--model", choices=CHAT_MODELS,
                        help="Override the default model for the selected task.")
    parser.add_argument("--question", default="Explain why APIs need authentication.")
    args = parser.parse_args()
    chosen = args.model or DEFAULT_ROUTE[args.task]
    require_models(args.base_url, [chosen])
    style = "Use three short sentences." if args.task == "quick" else "Use five concise bullet points."
    print(f"Task: {args.task}; selected model: {chosen}", flush=True)
    result = make_chat(chosen, args).invoke([
        ("system", "You are a technical trainer. " + style),
        ("human", args.question),
    ])
    print(text_content(result))


if __name__ == "__main__":
    run_cli(main)
