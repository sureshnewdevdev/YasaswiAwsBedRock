"""List the user's exact model tags without invoking a language model."""
import argparse
from common import CHAT_MODELS, EMBEDDING_MODEL, add_settings, installed_models, run_cli


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    add_settings(parser)
    args = parser.parse_args()
    installed = installed_models(args.base_url)
    print("Ollama server:", args.base_url)
    print("\nModels used in this workshop:")
    for model in (*CHAT_MODELS, EMBEDDING_MODEL):
        role = "embeddings" if model == EMBEDDING_MODEL else "chat"
        status = "INSTALLED" if model in installed else "MISSING"
        print(f"{status:9} {model:26} {role}")
    print("\nStart with: python 01_single_model.py")


if __name__ == "__main__":
    run_cli(main)
