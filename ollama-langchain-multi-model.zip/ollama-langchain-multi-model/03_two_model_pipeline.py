"""Lesson 3: one model drafts; a second model rewrites the draft."""
import argparse
from common import CHAT_MODELS, add_settings, make_chat, require_models, run_cli


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    add_settings(parser)
    parser.add_argument("--writer", choices=CHAT_MODELS, default="llama3.2:1b")
    parser.add_argument("--reviewer", choices=CHAT_MODELS, default="phi3:latest")
    parser.add_argument("--topic", default="What is a REST API?")
    args = parser.parse_args()
    from langchain_core.output_parsers import StrOutputParser
    from langchain_core.prompts import ChatPromptTemplate
    require_models(args.base_url, [args.writer, args.reviewer])

    draft_prompt = ChatPromptTemplate.from_messages([
        ("system", "Write a concise beginner explanation in at most 100 words."),
        ("human", "Topic: {topic}"),
    ])
    review_prompt = ChatPromptTemplate.from_messages([
        ("system", "Rewrite the draft clearly in at most 100 words. Correct obvious "
                   "technical mistakes. Return only the revised explanation."),
        ("human", "Original topic: {topic}\nDraft:\n{draft}"),
    ])
    writer_chain = draft_prompt | make_chat(args.writer, args) | StrOutputParser()
    reviewer_chain = review_prompt | make_chat(args.reviewer, args) | StrOutputParser()

    print("Draft model:", args.writer, flush=True)
    draft = writer_chain.invoke({"topic": args.topic})
    if not draft.strip():
        raise RuntimeError("Writer returned an empty draft. Increase --max-tokens.")
    print(draft)
    print("\nReview model:", args.reviewer, flush=True)
    revised = reviewer_chain.invoke({"topic": args.topic, "draft": draft})
    if not revised.strip():
        raise RuntimeError("Reviewer returned an empty answer. Increase --max-tokens.")
    print(revised)


if __name__ == "__main__":
    run_cli(main)
