import argparse
import unittest
from types import SimpleNamespace
from unittest.mock import patch
import common

class HelpersTest(unittest.TestCase):
    def test_cosine_ranks_identical_above_orthogonal(self):
        self.assertAlmostEqual(common.cosine_similarity([1, 0], [1, 0]), 1)
        self.assertAlmostEqual(common.cosine_similarity([1, 0], [0, 1]), 0)
        self.assertAlmostEqual(common.cosine_similarity([1, 0], [-1, 0]), -1)
    def test_invalid_vectors(self):
        for a, b in [([], []), ([1], [1, 2]), ([0, 0], [1, 2])]:
            with self.subTest(a=a, b=b), self.assertRaises(ValueError):
                common.cosine_similarity(a, b)
    def test_text_and_blocks(self):
        self.assertEqual(common.text_content(SimpleNamespace(content=' hi ')), 'hi')
        self.assertEqual(common.text_content(SimpleNamespace(content=[{'type':'text','text':'one'}, 'two'])), 'one\ntwo')
    def test_empty_answer(self):
        with self.assertRaises(RuntimeError):
            common.text_content(SimpleNamespace(content='  '))
    def test_positive_integer(self):
        self.assertEqual(common.positive_int('3'), 3)
        with self.assertRaises(argparse.ArgumentTypeError):
            common.positive_int('0')
    @patch('common.installed_models', return_value=['phi3:latest'])
    def test_exact_tags_required(self, mocked):
        common.require_models('http://localhost:11434', ['phi3:latest'])
        with self.assertRaisesRegex(RuntimeError, 'llama3.2:1b'):
            common.require_models('http://localhost:11434', ['llama3.2:1b'])
    def test_chat_settings_and_embedding_guard(self):
        args=SimpleNamespace(base_url='http://localhost:11434', max_tokens=128, timeout=60)
        fake=SimpleNamespace(ChatOllama=lambda **kwargs: kwargs)
        with patch.dict('sys.modules', {'langchain_ollama': fake}):
            result=common.make_chat('qwen3:8b', args)
            self.assertEqual(result['model'], 'qwen3:8b')
            self.assertFalse(result['reasoning'])
            self.assertEqual(result['keep_alive'], 0)
            self.assertNotIn('reasoning', common.make_chat('phi3:latest', args))
            with self.assertRaises(ValueError):
                common.make_chat(common.EMBEDDING_MODEL, args)

if __name__ == '__main__':
    unittest.main()
