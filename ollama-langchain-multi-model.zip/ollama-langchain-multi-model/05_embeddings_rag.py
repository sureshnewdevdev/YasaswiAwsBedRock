"""Lesson 5: nomic embeddings retrieve evidence; a chat model answers."""
import argparse
import json
from pathlib import Path
from common import (
    CHAT_MODELS, EMBEDDING_MODEL, add_settings, cosine_similarity,
    make_chat, positive_int, require_models, run_cli, text_content,
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    add_settings(parser)
    parser.add_argument("--model", choices=CHAT_MODELS, default="llama3.2:1b")
    parser.add_argument("--question", default="Who approves production access and how long does it last?")
    parser.add_argument("--top-k", type=positive_int, default=1)
    args = parser.parse_args()
    from langchain_ollama import OllamaEmbeddings
    require_models(args.base_url, [EMBEDDING_MODEL, args.model])

    path = Path(__file__).resolve().parent / "data" / "policies.json"
    documents = json.loads(path.read_text(encoding="utf-8"))
    if not documents:
        raise ValueError("The policy file has no documents.")
    embedder = OllamaEmbeddings(
        model=EMBEDDING_MODEL, base_url=args.base_url,
        client_kwargs={"timeout": args.timeout, "trust_env": False},
    )
    print("Embedding model:", EMBEDDING_MODEL, flush=True)
    vectors = embedder.embed_documents([
        "search_document: " + doc["text"] for doc in documents
    ])
    query_vector = embedder.embed_query("search_query: " + args.question)
    if len(vectors) != len(documents):
        raise ValueError("Embedding result count does not match the document count.")
    ranked = sorted(
        [(cosine_similarity(query_vector, vector), doc)
         for vector, doc in zip(vectors, documents)],
        key=lambda pair: pair[0], reverse=True,
    )[:args.top_k]
    print("\nRetrieved evidence:")
    for score, doc in ranked:
        print(f"{doc['id']} | cosine={score:.3f}")
        print(doc["text"])
    context = "\n\n".join(f"[{doc['id']}] {doc['text']}" for _, doc in ranked)
    print("\nAnswer model:", args.model, flush=True)
    response = make_chat(args.model, args).invoke([
        ("system", "Answer only from the supplied policy excerpts. If the excerpts "
                   "do not answer the question, say that evidence is missing. "
                   "Keep the answer under 100 words."),
        ("human", f"Question: {args.question}\n\nPolicy excerpts:\n{context}"),
    ])
    print(text_content(response))
    print("Retrieved source IDs:", ", ".join(doc["id"] for _, doc in ranked))


if __name__ == "__main__":
    run_cli(main)
