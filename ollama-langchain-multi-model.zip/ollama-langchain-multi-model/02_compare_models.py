"""Lesson 2: send the same prompt to multiple models, sequentially."""
import argparse
from time import perf_counter
from common import CHAT_MODELS, add_settings, make_chat, require_models, run_cli, text_content


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    add_settings(parser)
    parser.add_argument("--models", nargs="+", choices=CHAT_MODELS,
                        default=["llama3.2:1b", "phi3:latest"])
    parser.add_argument("--question", default="Explain DNS using a simple real-world example.")
    args = parser.parse_args()
    require_models(args.base_url, args.models)
    failures = []
    for name in args.models:
        print(f"\n--- {name} ---", flush=True)
        started = perf_counter()
        try:
            result = make_chat(name, args).invoke([
                ("system", "Answer in no more than five short sentences."),
                ("human", args.question),
            ])
            print(text_content(result))
            print(f"Elapsed seconds: {perf_counter() - started:.2f}")
        except Exception as error:
            failures.append(name)
            print(f"FAILED: {error}")
    if failures:
        print("\nFailed models:", ", ".join(failures))
        raise SystemExit(1)


if __name__ == "__main__":
    run_cli(main)
