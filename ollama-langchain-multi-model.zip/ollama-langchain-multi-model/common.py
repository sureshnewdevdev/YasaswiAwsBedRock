"""Small shared settings and Ollama connection checks for the five demos."""
import argparse
import json
import math
import os
from urllib.error import HTTPError, URLError
from urllib.request import ProxyHandler, Request, build_opener

CHAT_MODELS = (
    "llama3.2:1b",
    "phi3:latest",
    "llama3.2:latest",
    "qwen3:8b",
)
EMBEDDING_MODEL = "nomic-embed-text:latest"


def positive_int(value):
    number = int(value)
    if number <= 0:
        raise argparse.ArgumentTypeError("Use a positive integer.")
    return number


def add_settings(parser):
    parser.add_argument(
        "--base-url", default=os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434"),
        help="Ollama server URL. Default: http://127.0.0.1:11434",
    )
    parser.add_argument("--timeout", type=positive_int, default=240,
                        help="Client operation timeout in seconds. Default: 240")
    parser.add_argument("--max-tokens", type=positive_int, default=384,
                        help="Maximum generated tokens. Default: 384")


def installed_models(base_url):
    """Inspect an already-running Ollama server; never download a model."""
    url = base_url.rstrip("/") + "/api/tags"
    request = Request(url, headers={"Accept": "application/json"})
    # Local inference should not inherit a corporate HTTP proxy.
    opener = build_opener(ProxyHandler({}))
    try:
        with opener.open(request, timeout=10) as response:
            data = json.load(response)
    except (HTTPError, URLError, TimeoutError, OSError) as error:
        raise RuntimeError(
            f"Cannot reach Ollama at {base_url}. Open Ollama, or run 'ollama serve' "
            "if no server is already running. Check --base-url."
        ) from error
    names = [item.get("name") or item.get("model")
             for item in data.get("models", [])]
    return sorted({name for name in names if isinstance(name, str)})


def require_models(base_url, wanted):
    installed = installed_models(base_url)
    missing = sorted(set(wanted) - set(installed))
    if missing:
        raise RuntimeError(
            "Missing exact model tag(s): " + ", ".join(missing)
            + ". Run 'ollama list' and choose an installed tag."
        )


def make_chat(model, args):
    if model not in CHAT_MODELS:
        raise ValueError("Choose a chat model from CHAT_MODELS.")
    from langchain_ollama import ChatOllama

    settings = {
        "model": model,
        "base_url": args.base_url,
        "temperature": 0.2,
        "num_ctx": 2048,
        "num_predict": args.max_tokens,
        "keep_alive": 0,
        "client_kwargs": {"timeout": args.timeout, "trust_env": False},
    }
    if model == "qwen3:8b":
        settings["reasoning"] = False
    return ChatOllama(**settings)


def text_content(message):
    """Handle either text content or standard text content blocks."""
    content = message.content
    if isinstance(content, str):
        text = content
    elif isinstance(content, list):
        text = "\n".join(
            block if isinstance(block, str) else block.get("text", "")
            for block in content if isinstance(block, (str, dict))
        )
    else:
        text = ""
    if not text.strip():
        raise RuntimeError(
            "The model returned no answer text. Increase --max-tokens and check "
            "the model's thinking settings and Ollama version."
        )
    return text.strip()


def cosine_similarity(left, right):
    if not left or len(left) != len(right):
        raise ValueError("Embedding vectors must have equal, nonzero dimensions.")
    dot = sum(a * b for a, b in zip(left, right))
    magnitude = math.sqrt(sum(x * x for x in left) * sum(x * x for x in right))
    if magnitude == 0:
        raise ValueError("Cannot compare a zero-length embedding vector.")
    return dot / magnitude


def run_cli(main):
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped by user.")
        raise SystemExit(130)
    except Exception as error:
        print(f"ERROR: {error}")
        print("Check the README troubleshooting section.")
        raise SystemExit(1)
