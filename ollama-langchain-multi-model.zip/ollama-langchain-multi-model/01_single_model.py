"""Lesson 1: choose one installed model through ChatOllama."""
import argparse
from common import CHAT_MODELS, add_settings, make_chat, require_models, run_cli, text_content


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    add_settings(parser)
    parser.add_argument("--model", choices=CHAT_MODELS, default="llama3.2:1b")
    parser.add_argument("--question", default="Explain an API in three short sentences.")
    args = parser.parse_args()
    require_models(args.base_url, [args.model])
    print("Model:", args.model, flush=True)
    model = make_chat(args.model, args)
    response = model.invoke([
        ("system", "You are a concise, beginner-friendly technical trainer."),
        ("human", args.question),
    ])
    print(text_content(response))


if __name__ == "__main__":
    run_cli(main)
